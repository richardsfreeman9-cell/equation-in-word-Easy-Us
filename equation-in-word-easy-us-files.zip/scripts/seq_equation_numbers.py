#!/usr/bin/env python3
"""Replace equation-number markers in a .docx with live Word SEQ fields.

Markers (type them in the document where the number should appear):
  [[EQ]]     -> (1), (2), (3) ...            ({ SEQ Eq })
  [[EQ-A]]   -> first sub-equation (1a)      ({ SEQ Eq \\c }{ SEQ EqSub \\r 1 \\* alphabetic })
  [[EQ-SUB]] -> next sub-equation (1b, 1c)   ({ SEQ Eq \\c }{ SEQ EqSub \\* alphabetic })

The script writes real field codes and pre-fills the displayed result, so the numbers
show correctly even before Word recalculates. It also asks Word to update fields on open.

Usage: python3 seq_equation_numbers.py input.docx output.docx
"""
import copy, re, string, sys
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

MARK = re.compile(r"\[\[(EQ|EQ-A|EQ-SUB)\]\]")


def _fld(run_proto, instr, shown):
    """Build the 5 runs of one complex field: begin, instrText, separate, result, end."""
    runs = []
    def new_run():
        r = OxmlElement("w:r")
        if run_proto is not None and run_proto.find(qn("w:rPr")) is not None:
            r.append(copy.deepcopy(run_proto.find(qn("w:rPr"))))
        return r
    for kind in ("begin", None, "separate", "result", "end"):
        r = new_run()
        if kind in ("begin", "separate", "end"):
            fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), kind); r.append(fc)
        elif kind is None:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = f" {instr} "; r.append(it)
        else:
            t = OxmlElement("w:t"); t.text = shown; r.append(t)
        runs.append(r)
    return runs


def _text_run(run_proto, text):
    r = OxmlElement("w:r")
    if run_proto is not None and run_proto.find(qn("w:rPr")) is not None:
        r.append(copy.deepcopy(run_proto.find(qn("w:rPr"))))
    for i, part in enumerate(text.split("\t")):     # tabs must be <w:tab/>, not a tab character
        if i:
            r.append(OxmlElement("w:tab"))
        if part:
            t = OxmlElement("w:t"); t.set(qn("xml:space"), "preserve"); t.text = part; r.append(t)
    return r


def _paragraphs(doc):
    yield from doc.paragraphs
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                yield from cell.paragraphs


def convert(src, dst):
    doc = Document(src)
    main, sub, count, skipped = 0, 0, 0, 0
    for p in _paragraphs(doc):
        if "[[EQ" not in p.text:
            continue
        for run in list(p.runs):                     # edit run by run, so Word equation objects stay in place
            text = run.text
            if not MARK.search(text):
                continue
            proto, anchor, pos = run._r, run._r, 0
            new = []
            for m in MARK.finditer(text):
                if m.start() > pos:
                    new.append(_text_run(proto, text[pos:m.start()]))
                kind = m.group(1)
                new.append(_text_run(proto, "("))
                if kind == "EQ":
                    main += 1; sub = 0
                    new += _fld(proto, "SEQ Eq \\* MERGEFORMAT", str(main))
                else:
                    sub = 1 if kind == "EQ-A" else sub + 1
                    letter = string.ascii_lowercase[(sub - 1) % 26]
                    new += _fld(proto, "SEQ Eq \\c", str(max(main, 1)))
                    instr = "SEQ EqSub \\r 1 \\* alphabetic" if kind == "EQ-A" else "SEQ EqSub \\* alphabetic"
                    new += _fld(proto, instr, letter)
                new.append(_text_run(proto, ")"))
                pos = m.end(); count += 1
            if pos < len(text):
                new.append(_text_run(proto, text[pos:]))
            for r in new:
                anchor.addnext(r); anchor = r
            proto.getparent().remove(proto)
        if MARK.search("".join(r.text for r in p.runs)):
            skipped += 1                              # a marker split across runs (e.g. partly bold)
    if skipped:
        print(f"warning: {skipped} paragraph(s) have a marker split across formatting runs; retype those markers in one go")
    settings = doc.settings.element                   # make Word refresh all fields on open
    if settings.find(qn("w:updateFields")) is None:
        uf = OxmlElement("w:updateFields"); uf.set(qn("w:val"), "true"); settings.append(uf)
    doc.save(dst)
    return count


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    n = convert(sys.argv[1], sys.argv[2])
    print(f"inserted {n} equation numbers -> {sys.argv[2]}")
