---
name: Something did not number correctly
about: Tell us what you typed and what Word showed
labels: bug
---

**Word version and system** (for example Word 365, Windows 11):

**What you inserted** (press Alt + F9 to see the field codes and paste them here):

**What Word showed after Ctrl + A, F9:**

**What you expected:**
