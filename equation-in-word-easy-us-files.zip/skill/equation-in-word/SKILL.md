---
name: equation-in-word
description: Number equations in Microsoft Word with live SEQ fields, mixing main numbers (1), (2) with sub-equations (1a), (1b). Use when a user asks how to number or sub-number equations in Word, or wants a .docx with auto-updating equation numbers.
---

# Equation in Word

Microsoft Word numbers equations automatically with two `SEQ` (sequence) fields: `Eq` for the main number and `EqSub` for the letter. This gives (1), (1a), (1b), (2), (3), (3a) and renumbers itself whenever equations are added or moved.

Use this skill in two ways:
- **Explain it** to a user who will type the fields by hand (section "Manual procedure").
- **Build it** into a .docx with the script below (section "Automated insertion").

## The three field codes

| Purpose | Shows | Field code |
|---|---|---|
| New main equation | (1), (2), (3) | `({ SEQ Eq })` |
| First sub-equation of a group | (1a), (2a) | `({ SEQ Eq \c }{ SEQ EqSub \r 1 \* alphabetic })` |
| Next sub-equations | (1b), (1c) | `({ SEQ Eq \c }{ SEQ EqSub \* alphabetic })` |

- `\c` repeats the current main number without increasing it.
- `\r 1` restarts the letter sequence at 1, shown as "a".
- `\* alphabetic` displays the sequence as a, b, c.

## Manual procedure

1. **Insert field brackets with the shortcut.** Press Ctrl + F9 (Windows) or Cmd + F9 (Mac). Typed `{` and `}` keys do not create a field.
2. **Main equation (1, 2, 3).** Type `(`, press Ctrl + F9, type `SEQ Eq` inside the brackets, then type `)` outside them.
   Result: `({ SEQ Eq })`
3. **First sub-equation (1a, 2a).** Type `(`. Press Ctrl + F9 and type `SEQ Eq \c`. Click just outside that right bracket, press Ctrl + F9 again and type `SEQ EqSub \r 1 \* alphabetic`. Type `)`.
   Result: `({ SEQ Eq \c }{ SEQ EqSub \r 1 \* alphabetic })`
4. **Next sub-equations (1b, 1c).** Type `(`. Press Ctrl + F9 and type `SEQ Eq \c`. Click just outside it, press Ctrl + F9 and type `SEQ EqSub \* alphabetic`. Type `)`.
   Result: `({ SEQ Eq \c }{ SEQ EqSub \* alphabetic })`
5. **Update the fields.** Press Ctrl + A (Cmd + A) to select the whole document, then F9 (Fn + F9 on some laptops and Macs). The codes turn into (1), (1a), (1b), (2), (3).

**Tips**
- Build each of the three formats once, then copy and paste the field next to new equations.
- After adding, deleting or moving equations, press Ctrl + A then F9 again so Word recalculates the order.
- Alt + F9 (Windows) switches between showing field codes and their results.
- Start every group of sub-equations with the "first sub-equation" code. Otherwise the letters continue from the previous group (2d instead of 2a).
- A sub-equation group shares the number of the main equation that precedes it. To give a group its own new number, such as (2a) and (2b) with no plain (2), use `SEQ Eq` (no `\c`) in the first sub-equation of the group, followed by the `EqSub \r 1` field.

## Automated insertion (python-docx)

When asked to produce or fix a .docx, type a marker where each number should go and run the script. It writes real Word field codes, pre-fills the displayed numbers, and sets the document to refresh fields when opened.

| Marker | Becomes |
|---|---|
| `[[EQ]]` | ({ SEQ Eq }) → (1) |
| `[[EQ-A]]` | first sub-equation → (1a) |
| `[[EQ-SUB]]` | next sub-equation → (1b), (1c) |

```bash
pip install python-docx   # add --break-system-packages if pip requires it
python3 seq_equation_numbers.py input.docx output.docx
```

Steps:
1. Save the script below as `seq_equation_numbers.py`.
2. Work on a copy of the user's file, never the original.
3. Put each marker after its equation, separated by a right-aligned tab, or in the last column of a borderless table. Word equation objects in the same line stay in place. Type each marker in one go so it is not split across bold or italic formatting; the script warns if it is.
4. Run the script, then confirm the result by reading the paragraphs back or converting the file to text with LibreOffice.
5. Tell the user Word may ask "update the fields?" on opening. Answering Yes, or pressing Ctrl + A then F9, recalculates the numbers.

Tested behavior: markers in the order EQ, EQ-A, EQ-SUB, EQ-SUB, EQ, EQ, EQ-A, EQ-SUB produce (1), (1a), (1b), (1c), (2), (3), (3a), (3b), and LibreOffice reads them back with the same numbers. A marker placed after a Word equation object keeps the equation in front of the number.

```python
#!/usr/bin/env python3
"""Replace equation-number markers in a .docx with live Word SEQ fields.

Markers (type them in the document where the number should appear):
  [[EQ]]     -> (1), (2), (3) ...            ({ SEQ Eq })
  [[EQ-A]]   -> first sub-equation (1a)      ({ SEQ Eq \\c }{ SEQ EqSub \\r 1 \\* alphabetic })
  [[EQ-SUB]] -> next sub-equation (1b, 1c)   ({ SEQ Eq \\c }{ SEQ EqSub \\* alphabetic })

The script writes real field codes and pre-fills the displayed result, so the numbers
show correctly even before Word recalculates. It also asks Word to update fields on open.

Usage: python3 seq_equation_numbers.py input.docx output.docx
"""
import copy, re, string, sys
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

MARK = re.compile(r"\[\[(EQ|EQ-A|EQ-SUB)\]\]")


def _fld(run_proto, instr, shown):
    """Build the 5 runs of one complex field: begin, instrText, separate, result, end."""
    runs = []
    def new_run():
        r = OxmlElement("w:r")
        if run_proto is not None and run_proto.find(qn("w:rPr")) is not None:
            r.append(copy.deepcopy(run_proto.find(qn("w:rPr"))))
        return r
    for kind in ("begin", None, "separate", "result", "end"):
        r = new_run()
        if kind in ("begin", "separate", "end"):
            fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), kind); r.append(fc)
        elif kind is None:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = f" {instr} "; r.append(it)
        else:
            t = OxmlElement("w:t"); t.text = shown; r.append(t)
        runs.append(r)
    return runs


def _text_run(run_proto, text):
    r = OxmlElement("w:r")
    if run_proto is not None and run_proto.find(qn("w:rPr")) is not None:
        r.append(copy.deepcopy(run_proto.find(qn("w:rPr"))))
    for i, part in enumerate(text.split("\t")):     # tabs must be <w:tab/>, not a tab character
        if i:
            r.append(OxmlElement("w:tab"))
        if part:
            t = OxmlElement("w:t"); t.set(qn("xml:space"), "preserve"); t.text = part; r.append(t)
    return r


def _paragraphs(doc):
    yield from doc.paragraphs
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                yield from cell.paragraphs


def convert(src, dst):
    doc = Document(src)
    main, sub, count, skipped = 0, 0, 0, 0
    for p in _paragraphs(doc):
        if "[[EQ" not in p.text:
            continue
        for run in list(p.runs):                     # edit run by run, so Word equation objects stay in place
            text = run.text
            if not MARK.search(text):
                continue
            proto, anchor, pos = run._r, run._r, 0
            new = []
            for m in MARK.finditer(text):
                if m.start() > pos:
                    new.append(_text_run(proto, text[pos:m.start()]))
                kind = m.group(1)
                new.append(_text_run(proto, "("))
                if kind == "EQ":
                    main += 1; sub = 0
                    new += _fld(proto, "SEQ Eq \\* MERGEFORMAT", str(main))
                else:
                    sub = 1 if kind == "EQ-A" else sub + 1
                    letter = string.ascii_lowercase[(sub - 1) % 26]
                    new += _fld(proto, "SEQ Eq \\c", str(max(main, 1)))
                    instr = "SEQ EqSub \\r 1 \\* alphabetic" if kind == "EQ-A" else "SEQ EqSub \\* alphabetic"
                    new += _fld(proto, instr, letter)
                new.append(_text_run(proto, ")"))
                pos = m.end(); count += 1
            if pos < len(text):
                new.append(_text_run(proto, text[pos:]))
            for r in new:
                anchor.addnext(r); anchor = r
            proto.getparent().remove(proto)
        if MARK.search("".join(r.text for r in p.runs)):
            skipped += 1                              # a marker split across runs (e.g. partly bold)
    if skipped:
        print(f"warning: {skipped} paragraph(s) have a marker split across formatting runs; retype those markers in one go")
    settings = doc.settings.element                   # make Word refresh all fields on open
    if settings.find(qn("w:updateFields")) is None:
        uf = OxmlElement("w:updateFields"); uf.set(qn("w:val"), "true"); settings.append(uf)
    doc.save(dst)
    return count


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    n = convert(sys.argv[1], sys.argv[2])
    print(f"inserted {n} equation numbers -> {sys.argv[2]}")
```
