# Equation in Word: (1), (1a), (1b), (2) that renumber themselves

**Stop typing equation numbers by hand.** Two Word field codes number every equation in your thesis or paper, including sub-equations such as (1a) and (1b). Add, delete or move an equation, press <kbd>Ctrl</kbd> + <kbd>A</kbd> then <kbd>F9</kbd>, and every number updates.

![Field codes on the left, the numbers Word shows on the right](docs/demo.png)

No macros, no add-ins and nothing to install. It works in any recent Microsoft Word on Windows or Mac. A small Python script and a Claude skill are included if you want to automate it.

---

## Contents
- [The three codes to copy](#the-three-codes-to-copy)
- [Step by step in Word](#step-by-step-in-word)
- [Tips and common mistakes](#tips-and-common-mistakes)
- [Automate it with Python](#automate-it-with-python)
- [Use it as a Claude skill](#use-it-as-a-claude-skill)
- [FAQ](#faq)
- [Contributing](#contributing)

## The three codes to copy

| You want | Word shows | Field code |
|---|---|---|
| A new main equation | (1), (2), (3) | `({ SEQ Eq })` |
| The **first** sub-equation of a group | (1a), (2a) | `({ SEQ Eq \c }{ SEQ EqSub \r 1 \* alphabetic })` |
| The **next** sub-equations | (1b), (1c) | `({ SEQ Eq \c }{ SEQ EqSub \* alphabetic })` |

What the switches do:
- `\c` repeats the current main number instead of increasing it.
- `\r 1` restarts the letter counter, so the group starts at "a".
- `\* alphabetic` shows the counter as a, b, c instead of 1, 2, 3.

## Step by step in Word

> The curly brackets must be **field brackets**. Insert them with <kbd>Ctrl</kbd> + <kbd>F9</kbd> (Windows) or <kbd>Cmd</kbd> + <kbd>F9</kbd> (Mac). Typing `{` and `}` on the keyboard does not work.

**1. Main equation: (1), (2), (3)**
1. Type `(`
2. Press <kbd>Ctrl</kbd> + <kbd>F9</kbd> and type `SEQ Eq` inside the brackets.
3. Type `)` after the brackets.

You now have `({ SEQ Eq })`.

**2. First sub-equation: (1a), (2a)**
1. Type `(`
2. Press <kbd>Ctrl</kbd> + <kbd>F9</kbd> and type `SEQ Eq \c`
3. Click just outside that right bracket, press <kbd>Ctrl</kbd> + <kbd>F9</kbd> again and type `SEQ EqSub \r 1 \* alphabetic`
4. Type `)`

You now have `({ SEQ Eq \c }{ SEQ EqSub \r 1 \* alphabetic })`.

**3. Next sub-equations: (1b), (1c)**
1. Type `(`
2. Press <kbd>Ctrl</kbd> + <kbd>F9</kbd> and type `SEQ Eq \c`
3. Click just outside it, press <kbd>Ctrl</kbd> + <kbd>F9</kbd> and type `SEQ EqSub \* alphabetic`
4. Type `)`

You now have `({ SEQ Eq \c }{ SEQ EqSub \* alphabetic })`.

**4. Show the numbers**
Press <kbd>Ctrl</kbd> + <kbd>A</kbd> (<kbd>Cmd</kbd> + <kbd>A</kbd>) to select everything, then <kbd>F9</kbd> (<kbd>Fn</kbd> + <kbd>F9</kbd> on some laptops and Macs). The codes turn into (1), (1a), (1b), (2), (3).

## Tips and common mistakes

- **Build each code once, then copy and paste it** next to new equations. You never retype it.
- **Update after every change.** Word does not renumber on its own. Press <kbd>Ctrl</kbd> + <kbd>A</kbd> then <kbd>F9</kbd> after adding, deleting or moving equations.
- **See the codes again** with <kbd>Alt</kbd> + <kbd>F9</kbd> on Windows. Press it again to go back to the numbers.
- **Always open a group with the "first sub-equation" code.** If you skip it, the letters continue from the previous group, giving (2d) instead of (2a).
- **Want (2a), (2b) with no plain (2)?** Use `SEQ Eq` without `\c` in the first sub-equation of the group, followed by the `EqSub \r 1` field.
- **Layout:** put each equation and its number in a two-column borderless table, with the number right-aligned in the last column. Or use a right-aligned tab stop.

## Automate it with Python

`scripts/seq_equation_numbers.py` turns plain-text markers into real Word fields. Type a marker where each number should go:

| Marker | Becomes |
|---|---|
| `[[EQ]]` | (1), (2), (3) |
| `[[EQ-A]]` | first sub-equation: (1a) |
| `[[EQ-SUB]]` | next sub-equation: (1b), (1c) |

```bash
pip install python-docx
python3 scripts/seq_equation_numbers.py my_paper.docx my_paper_numbered.docx
```

The script:
- writes genuine `SEQ` field codes, so Word keeps renumbering them later;
- fills in the correct numbers straight away, so they show even before you press F9;
- leaves Word equation objects where they are;
- works in body text and in tables;
- asks Word to refresh all fields when the file opens. Answer **Yes** to Word's "update the fields?" prompt.

Try it on the included example: `examples/example_input.docx` becomes `examples/example_output.docx`.

Run the tests with:

```bash
pip install python-docx pytest
pytest -q
```

## Use it as a Claude skill

`skill/equation-in-word/SKILL.md` packages the guide and the script as a skill for Claude. Add the `skill/equation-in-word` folder to your skills, then ask Claude, for example, "number the equations in my thesis with sub-equations".

## FAQ

**Does it work on Mac?** Yes. Use <kbd>Cmd</kbd> + <kbd>F9</kbd> for the brackets and <kbd>Fn</kbd> + <kbd>F9</kbd> to update if F9 controls your screen or volume.

**Can I refer to an equation in the text, like "see Equation (2)"?** Yes. Select the number, then choose **Insert → Bookmark** and name it. Then use **Insert → Cross-reference → Bookmark** wherever you mention it. Update with <kbd>F9</kbd> as usual.

**Can numbering restart in each chapter, as in (3.1)?** Add `\s 1` to the main field, `{ SEQ Eq \s 1 }`. The counter then restarts after each Heading 1. Type the chapter number before it yourself, or with a `{ STYLEREF 1 \s }` field if your headings are numbered.

**Why do I see `{ SEQ Eq }` instead of a number?** Field codes are showing. Press <kbd>Alt</kbd> + <kbd>F9</kbd>, then <kbd>Ctrl</kbd> + <kbd>A</kbd> and <kbd>F9</kbd>.

**Why does the code stay as plain text after F9?** The curly brackets were typed on the keyboard, so Word treats them as ordinary text. Delete them and insert real field brackets with <kbd>Ctrl</kbd> + <kbd>F9</kbd>.

**LibreOffice and Google Docs?** LibreOffice Writer opens these files and keeps the numbers as its own number-range fields. Google Docs does not support Word field codes.

## Contributing

Improvements are welcome, especially:
- tested notes for other Word versions and languages;
- extra marker types, such as chapter-based numbering;
- translations of this guide.

See [CONTRIBUTING.md](CONTRIBUTING.md). If this saved you an afternoon of renumbering, please star the repository and share it with your lab or thesis group.

## License

[MIT](LICENSE)
