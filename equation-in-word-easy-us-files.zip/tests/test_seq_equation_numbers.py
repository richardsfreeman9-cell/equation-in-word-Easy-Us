import pathlib, subprocess, sys
from docx import Document

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "seq_equation_numbers.py"


def _run(tmp_path, lines):
    src, dst = tmp_path / "in.docx", tmp_path / "out.docx"
    d = Document()
    for line in lines:
        d.add_paragraph(line)
    d.save(src)
    subprocess.run([sys.executable, str(SCRIPT), str(src), str(dst)], check=True, capture_output=True)
    return dst


def test_numbers_and_letters(tmp_path):
    dst = _run(tmp_path, ["a\t[[EQ]]", "b\t[[EQ-A]]", "c\t[[EQ-SUB]]", "d\t[[EQ]]", "e\t[[EQ]]", "f\t[[EQ-A]]"])
    shown = [p.text.split("\t")[1] for p in Document(dst).paragraphs]
    assert shown == ["(1)", "(1a)", "(1b)", "(2)", "(3)", "(3a)"]


def test_real_field_codes_and_update_flag(tmp_path):
    import zipfile
    dst = _run(tmp_path, ["x\t[[EQ]]", "y\t[[EQ-A]]", "z\t[[EQ-SUB]]"])
    with zipfile.ZipFile(dst) as z:
        doc = z.read("word/document.xml").decode()
        settings = z.read("word/settings.xml").decode()
    assert "SEQ Eq \\c" in doc
    assert "SEQ EqSub \\r 1 \\* alphabetic" in doc
    assert "SEQ EqSub \\* alphabetic" in doc
    assert "updateFields" in settings
