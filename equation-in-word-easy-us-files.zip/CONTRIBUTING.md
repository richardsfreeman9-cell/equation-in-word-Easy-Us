# Contributing

Thank you for helping researchers and students number their equations faster.

## Ways to help
- **Report a problem:** open an issue with your Word version (Windows or Mac), what you typed and what Word showed.
- **Improve the guide:** fix wording, add a screenshot, or add a tested tip to the README.
- **Improve the script:** keep it to a single file with `python-docx` as the only dependency.

## Before opening a pull request
1. Run the tests: `pip install python-docx pytest && pytest -q`.
2. If you change the script, copy it to `skill/equation-in-word/scripts/` as well, and update the code block in `skill/equation-in-word/SKILL.md`.
3. Describe what you tested and in which version of Word.
